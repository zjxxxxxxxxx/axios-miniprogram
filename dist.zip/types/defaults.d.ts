import { AxiosRequestConfig } from './core/Axios';
declare const defaults: AxiosRequestConfig;
export default defaults;
