import { AxiosRequestConfig } from './Axios';
export declare function transformURL(config: AxiosRequestConfig): string;
