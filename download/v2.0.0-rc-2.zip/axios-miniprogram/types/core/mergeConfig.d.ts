import { AxiosRequestConfig } from './Axios';
export declare function mergeConfig(config1?: AxiosRequestConfig, config2?: AxiosRequestConfig): AxiosRequestConfig;
