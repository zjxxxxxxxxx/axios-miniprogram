import { AxiosAdapterRequestType } from './adapter';
import { AxiosRequestConfig } from './Axios';
export declare function generateType(config: AxiosRequestConfig): AxiosAdapterRequestType;
