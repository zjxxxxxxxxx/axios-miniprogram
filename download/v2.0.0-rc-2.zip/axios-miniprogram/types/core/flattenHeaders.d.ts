import { AxiosRequestConfig, AxiosRequestHeaders } from './Axios';
export declare function flattenHeaders(config: AxiosRequestConfig): AxiosRequestHeaders | undefined;
